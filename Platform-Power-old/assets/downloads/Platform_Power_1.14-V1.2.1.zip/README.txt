Hello,


A few things before you get started:

1) This map is not copyleft, you cannot upload or modify this map without the
    creator's permission (Alkali_metal).
2) This map is a port of another map which was originally designed by Jarren and
    Ben Baptist, Alkali_metal has received permission from Jarren to port the map.
3) For operator control of the game, stand directly on the button in the middle of
    of the lobby and press the button, this will give you the control book from
    where you can control which teams are active and all the other fun options.
    This is also where you start the game from!
3) To credit the creators of the map in videos and streams, please link to:
    https://alkali-metal.github.io/maps/platform-power/index.html



You can see all the maps Alkali_metal has worked on and/or made here:
    https://alkali-metal.github.io/maps
