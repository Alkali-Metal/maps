The textures in this resource pack were made and contributed by various people, below is an exact list of textures and their artists.

Alan (twitter.com/CultOfAlan):
	- fire_charge.png
	- redstone_dust_line0.png
	- redstone_dust_line1.png

Tyler Akins (twitter.com/Eldritch_Tyler):
	- redstone_dust_dot.png
