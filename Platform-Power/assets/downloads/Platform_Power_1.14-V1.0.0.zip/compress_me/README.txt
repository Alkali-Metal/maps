Hello,


A few things before you get started:

1) This map is not copyleft, you cannot upload or modify this map without the
    creator's permission (Alkali_metal).
2) This map is a port of another map which was originally designed by Jarren and
    Ben Baptist, Alkali_metal has received permission from Jarren to port the map.
3) To credit the creators of the map in videos and streams, please link to:
    https://alkali-metal.github.io/maps/platform-power/index.html



You can see all the maps Alkali_metal has worked on and/or made here:
    https://alkali-metal.github.io/maps